<?php
/**
 * Plugin Name: TreeVine News Player
 * Plugin URI: https://treevine.org
 * Description: Automatically downloads hourly news from Google Drive to WordPress Media Library and plays it with timezone-aware timestamps
 * Version: 6.0.0
 * Author: TreeVine News
 * Author URI: https://treevine.org
 * License: GPL v2 or later
 * Text Domain: treevine-news
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('TREEVINE_VERSION', '6.0.0');
define('TREEVINE_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('TREEVINE_PLUGIN_URL', plugin_dir_url(__FILE__));

/**
 * Main TreeVine News Player Class
 */
class TreeVine_News_Player {
    
    private static $instance = null;
    private $media_filename = 'treevine-latest-news.mp3';
    
    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        // Register hooks
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_shortcode('treevine_news', array($this, 'render_player_shortcode'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
        
        // Add custom cron schedules
        add_filter('cron_schedules', array($this, 'add_cron_schedules'));
        
        // Register AJAX handlers
        add_action('wp_ajax_treevine_download_now', array($this, 'ajax_download_now'));
        add_action('wp_ajax_treevine_get_status', array($this, 'ajax_get_status'));
        add_action('wp_ajax_treevine_check_file_update', array($this, 'ajax_check_file_update'));
        add_action('wp_ajax_nopriv_treevine_check_file_update', array($this, 'ajax_check_file_update'));
        
        // Register cron job
        add_action('treevine_auto_download', array($this, 'auto_download_file'));
        
        // Schedule cron on activation
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Schedule cron based on settings
        $this->schedule_auto_download();
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Clear scheduled cron
        wp_clear_scheduled_hook('treevine_auto_download');
    }
    
    /**
     * Add custom cron schedules
     */
    public function add_cron_schedules($schedules) {
        $frequency = get_option('treevine_update_frequency', 1);
        
        // Add custom intervals for different frequencies
        $schedules['treevine_1hour'] = array(
            'interval' => 1 * HOUR_IN_SECONDS,
            'display' => __('Every 1 hour')
        );
        $schedules['treevine_2hours'] = array(
            'interval' => 2 * HOUR_IN_SECONDS,
            'display' => __('Every 2 hours')
        );
        $schedules['treevine_3hours'] = array(
            'interval' => 3 * HOUR_IN_SECONDS,
            'display' => __('Every 3 hours')
        );
        $schedules['treevine_4hours'] = array(
            'interval' => 4 * HOUR_IN_SECONDS,
            'display' => __('Every 4 hours')
        );
        $schedules['treevine_6hours'] = array(
            'interval' => 6 * HOUR_IN_SECONDS,
            'display' => __('Every 6 hours')
        );
        $schedules['treevine_12hours'] = array(
            'interval' => 12 * HOUR_IN_SECONDS,
            'display' => __('Every 12 hours')
        );
        $schedules['treevine_24hours'] = array(
            'interval' => 24 * HOUR_IN_SECONDS,
            'display' => __('Every 24 hours')
        );
        
        return $schedules;
    }
    
    /**
     * Schedule auto download based on settings
     */
    private function schedule_auto_download() {
        // Clear existing schedule
        wp_clear_scheduled_hook('treevine_auto_download');
        
        // Check if auto-download is enabled
        $enabled = get_option('treevine_auto_download_enabled', '1');
        if ($enabled != '1') {
            return; // Don't schedule if disabled
        }
        
        // Get update frequency (in hours)
        $frequency = get_option('treevine_update_frequency', 1);
        
        // Map frequency to schedule name
        $schedule_map = array(
            1 => 'treevine_1hour',
            2 => 'treevine_2hours',
            3 => 'treevine_3hours',
            4 => 'treevine_4hours',
            6 => 'treevine_6hours',
            12 => 'treevine_12hours',
            24 => 'treevine_24hours'
        );
        
        $schedule = isset($schedule_map[$frequency]) ? $schedule_map[$frequency] : 'treevine_1hour';
        
        // Schedule next run
        if (!wp_next_scheduled('treevine_auto_download')) {
            wp_schedule_event(time(), $schedule, 'treevine_auto_download');
        }
    }
    
    /**
     * Add admin menu page
     */
    public function add_admin_menu() {
        add_options_page(
            'TreeVine News Settings',
            'TreeVine News',
            'manage_options',
            'treevine-news-settings',
            array($this, 'render_settings_page')
        );
    }
    
    /**
     * Register plugin settings
     */
    public function register_settings() {
        register_setting('treevine_news_settings', 'treevine_google_drive_url');
        register_setting('treevine_news_settings', 'treevine_player_title');
        register_setting('treevine_news_settings', 'treevine_update_frequency');
        register_setting('treevine_news_settings', 'treevine_auto_download_enabled');
        register_setting('treevine_news_settings', 'treevine_timezone');
        register_setting('treevine_news_settings', 'treevine_mini_player');
        register_setting('treevine_news_settings', 'treevine_show_volume');
        register_setting('treevine_news_settings', 'treevine_show_timeline');
        register_setting('treevine_news_settings', 'treevine_date_format');
        
        add_settings_section(
            'treevine_main_settings',
            'Main Settings',
            array($this, 'settings_section_callback'),
            'treevine-news-settings'
        );
        
        add_settings_field(
            'treevine_google_drive_url',
            'Google Drive File URL',
            array($this, 'google_drive_url_callback'),
            'treevine-news-settings',
            'treevine_main_settings'
        );
        
        add_settings_field(
            'treevine_player_title',
            'Player Title',
            array($this, 'player_title_callback'),
            'treevine-news-settings',
            'treevine_main_settings'
        );
        
        add_settings_field(
            'treevine_auto_download_enabled',
            'Auto-Download',
            array($this, 'auto_download_callback'),
            'treevine-news-settings',
            'treevine_main_settings'
        );
        
        add_settings_field(
            'treevine_update_frequency',
            'Update Frequency',
            array($this, 'update_frequency_callback'),
            'treevine-news-settings',
            'treevine_main_settings'
        );
        
        add_settings_field(
            'treevine_timezone',
            'Timezone',
            array($this, 'timezone_callback'),
            'treevine-news-settings',
            'treevine_main_settings'
        );
        
        add_settings_field(
            'treevine_mini_player',
            'Mini Player Mode',
            array($this, 'mini_player_callback'),
            'treevine-news-settings',
            'treevine_main_settings'
        );
        
        add_settings_field(
            'treevine_show_volume',
            'Show Volume Control',
            array($this, 'show_volume_callback'),
            'treevine-news-settings',
            'treevine_main_settings'
        );
        
        add_settings_field(
            'treevine_show_timeline',
            'Show Timeline Control',
            array($this, 'show_timeline_callback'),
            'treevine-news-settings',
            'treevine_main_settings'
        );
        
        add_settings_field(
            'treevine_date_format',
            'Mini Player Date Format',
            array($this, 'date_format_callback'),
            'treevine-news-settings',
            'treevine_main_settings'
        );
    }
    
    /**
     * Settings section description
     */
    public function settings_section_callback() {
        echo '<p>Configure your TreeVine News audio stream. The file will be downloaded from Google Drive to your WordPress Media Library.</p>';
    }
    
    /**
     * Google Drive URL field
     */
    public function google_drive_url_callback() {
        $url = get_option('treevine_google_drive_url', '');
        echo '<input type="url" name="treevine_google_drive_url" value="' . esc_attr($url) . '" class="regular-text" placeholder="https://drive.google.com/file/d/..." />';
        echo '<p class="description">Enter the Google Drive share URL for your MP3 file.</p>';
    }
    
    /**
     * Player title field
     */
    public function player_title_callback() {
        $title = get_option('treevine_player_title', 'Latest Hourly News');
        echo '<input type="text" name="treevine_player_title" value="' . esc_attr($title) . '" class="regular-text" />';
        echo '<p class="description">The title displayed above the player.</p>';
    }
    
    /**
     * Auto download enabled checkbox
     */
    public function auto_download_callback() {
        $enabled = get_option('treevine_auto_download_enabled', '1');
        echo '<label><input type="checkbox" name="treevine_auto_download_enabled" value="1" ' . checked($enabled, '1', false) . ' /> Enable automatic downloads</label>';
        echo '<p class="description">Automatically download the file from Google Drive at the specified frequency.</p>';
    }
    
    /**
     * Update frequency field
     */
    public function update_frequency_callback() {
        $frequency = get_option('treevine_update_frequency', 1);
        ?>
        <select name="treevine_update_frequency">
            <option value="1" <?php selected($frequency, 1); ?>>Every 1 hour</option>
            <option value="2" <?php selected($frequency, 2); ?>>Every 2 hours</option>
            <option value="3" <?php selected($frequency, 3); ?>>Every 3 hours</option>
            <option value="4" <?php selected($frequency, 4); ?>>Every 4 hours</option>
            <option value="6" <?php selected($frequency, 6); ?>>Every 6 hours</option>
            <option value="12" <?php selected($frequency, 12); ?>>Every 12 hours</option>
            <option value="24" <?php selected($frequency, 24); ?>>Every 24 hours</option>
        </select>
        <p class="description">How often to check for and download the updated file from Google Drive.</p>
        <?php
    }
    
    /**
     * Timezone selection field
     */
    public function timezone_callback() {
        $selected_timezone = get_option('treevine_timezone', wp_timezone_string());
        $timezones = timezone_identifiers_list();
        ?>
        <select name="treevine_timezone" class="regular-text">
            <?php foreach ($timezones as $timezone): ?>
                <option value="<?php echo esc_attr($timezone); ?>" <?php selected($selected_timezone, $timezone); ?>>
                    <?php echo esc_html($timezone); ?>
                </option>
            <?php endforeach; ?>
        </select>
        <p class="description">Timezone for displaying news timestamps. Defaults to WordPress timezone. Currently: <strong><?php echo esc_html($selected_timezone); ?></strong></p>
        <?php
    }
    
    /**
     * Mini player mode checkbox
     */
    public function mini_player_callback() {
        $mini = get_option('treevine_mini_player', '0');
        echo '<label><input type="checkbox" name="treevine_mini_player" value="1" ' . checked($mini, '1', false) . ' /> Enable mini player mode (320x100px compact view)</label>';
        echo '<p class="description">Optimized for small containers. Hides some controls for compact display.</p>';
    }
    
    /**
     * Show volume control checkbox
     */
    public function show_volume_callback() {
        $show = get_option('treevine_show_volume', '1');
        echo '<label><input type="checkbox" name="treevine_show_volume" value="1" ' . checked($show, '1', false) . ' /> Show volume control in player</label>';
        echo '<p class="description">Display the volume slider. Recommended to hide in mini player mode.</p>';
    }
    
    /**
     * Show timeline control checkbox
     */
    public function show_timeline_callback() {
        $show = get_option('treevine_show_timeline', '1');
        echo '<label><input type="checkbox" name="treevine_show_timeline" value="1" ' . checked($show, '1', false) . ' /> Show timeline/progress bar</label>';
        echo '<p class="description">Display the progress bar and time indicators. Recommended to hide in mini player mode.</p>';
    }
    
    /**
     * Date format field for mini player
     */
    public function date_format_callback() {
        $format = get_option('treevine_date_format', 'F j, Y');
        ?>
        <input type="text" name="treevine_date_format" value="<?php echo esc_attr($format); ?>" class="regular-text" placeholder="F j, Y" />
        <p class="description">
            Date format for mini player header (e.g., "TV-SNS December 9, 2025"). 
            Uses PHP date format. Common formats:
        </p>
        <p class="description">
            • <code>F j, Y</code> = December 9, 2025<br>
            • <code>m/d/Y</code> = 12/09/2025<br>
            • <code>Y-m-d</code> = 2025-12-09<br>
            • <code>l, F j</code> = Monday, December 9<br>
            <a href="https://www.php.net/manual/en/datetime.format.php" target="_blank">Full format reference</a>
        </p>
        <?php
    }
    
    /**
     * Render settings page
     */
    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        // Show success message if settings saved
        if (isset($_GET['settings-updated'])) {
            add_settings_error('treevine_messages', 'treevine_message', 'Settings Saved', 'updated');
            // Reschedule cron with new settings
            $this->schedule_auto_download();
        }
        
        settings_errors('treevine_messages');
        
        // Get current media file info
        $media_file = $this->get_media_file();
        $last_download = get_option('treevine_last_download', '');
        $next_download = wp_next_scheduled('treevine_auto_download');
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <form action="options.php" method="post">
                <?php
                settings_fields('treevine_news_settings');
                do_settings_sections('treevine-news-settings');
                submit_button('Save Settings');
                ?>
            </form>
            
            <hr>
            
            <h2>File Status <span style="font-size: 12px; color: #666;">(Updates automatically every 30 seconds <span id="treevine-ajax-indicator" style="display:inline-block;width:8px;height:8px;background:#ccc;border-radius:50%;margin-left:5px;"></span>)</span></h2>
            <div id="treevine-status-container">
            <table class="form-table">
                <tr>
                    <th>Current Media File:</th>
                    <td>
                        <?php if ($media_file): ?>
                            <a href="<?php echo esc_url($media_file['url']); ?>" target="_blank">
                                <?php echo esc_html(basename($media_file['file'])); ?>
                            </a>
                            (<?php echo size_format(filesize($media_file['file'])); ?>)
                        <?php else: ?>
                            <em>No file downloaded yet</em>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th>Last Download:</th>
                    <td><?php echo $last_download ? esc_html($last_download) : '<em>Never</em>'; ?></td>
                </tr>
                <tr>
                    <th>Auto-Download Status:</th>
                    <td>
                        <?php 
                        $auto_enabled = get_option('treevine_auto_download_enabled', '1');
                        if ($auto_enabled == '1' && $next_download): 
                        ?>
                            <span style="color: green;">✓ Active</span> - Updates every <?php echo get_option('treevine_update_frequency', 1); ?> hour(s)
                        <?php elseif ($auto_enabled == '1' && !$next_download): ?>
                            <span style="color: orange;">⚠ Enabled but not scheduled</span> - Save settings to activate
                        <?php else: ?>
                            <span style="color: gray;">○ Disabled</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th>Next Scheduled Download:</th>
                    <td>
                        <?php if ($next_download): ?>
                            <strong><?php echo esc_html(date('Y-m-d H:i:s', $next_download)); ?></strong>
                            <span style="color: #666;">(<?php echo human_time_diff($next_download); ?>)</span>
                        <?php else: ?>
                            <em>Not scheduled - <?php echo $auto_enabled == '1' ? 'Save settings to schedule' : 'Enable auto-download to schedule'; ?></em>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>
            </div>
            
            <p>
                <button type="button" class="button button-primary" id="treevine-download-now">
                    Download from Google Drive Now
                </button>
                <span class="spinner" style="float: none; margin: 0 10px;"></span>
                <span id="treevine-download-status"></span>
            </p>
            
            <hr>
            
            <h2>Usage</h2>
            <p>Use this shortcode to display the player anywhere on your site:</p>
            <code style="background: #f0f0f0; padding: 10px; display: inline-block;">[treevine_news]</code>
            
            <h3>Shortcode Attributes (Optional)</h3>
            <ul>
                <li><code>[treevine_news title="Custom Title"]</code> - Override the default title</li>
            </ul>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // Manual download button
            $('#treevine-download-now').on('click', function() {
                var $btn = $(this);
                var $spinner = $btn.next('.spinner');
                var $status = $('#treevine-download-status');
                
                $btn.prop('disabled', true);
                $spinner.addClass('is-active');
                $status.html('Downloading...');
                
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'treevine_download_now'
                    },
                    success: function(response) {
                        $spinner.removeClass('is-active');
                        $btn.prop('disabled', false);
                        
                        if (response.success) {
                            $status.html('<span style="color: green;">✓ ' + response.data.message + '</span>');
                            setTimeout(function() {
                                location.reload();
                            }, 1500);
                        } else {
                            $status.html('<span style="color: red;">✗ ' + response.data.message + '</span>');
                        }
                    },
                    error: function() {
                        $spinner.removeClass('is-active');
                        $btn.prop('disabled', false);
                        $status.html('<span style="color: red;">✗ Error downloading file</span>');
                    }
                });
            });
            
            // Auto-refresh status every 30 seconds
            function refreshStatus() {
                // Flash indicator green
                $('#treevine-ajax-indicator').css('background', '#46b450');
                
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'treevine_get_status'
                    },
                    success: function(response) {
                        if (response.success && response.data.html) {
                            $('#treevine-status-container').html(response.data.html);
                            // Keep green for 2 seconds then fade to gray
                            setTimeout(function() {
                                $('#treevine-ajax-indicator').css('background', '#ccc');
                            }, 2000);
                        }
                    },
                    error: function() {
                        // Flash red on error
                        $('#treevine-ajax-indicator').css('background', '#dc3232');
                        setTimeout(function() {
                            $('#treevine-ajax-indicator').css('background', '#ccc');
                        }, 2000);
                    }
                });
            }
            
            // Initial load
            refreshStatus();
            
            // Refresh status every 30 seconds
            setInterval(refreshStatus, 30000);
        });
        </script>
        <?php
    }
    
    /**
     * AJAX handler for status updates
     */
    public function ajax_get_status() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error();
        }
        
        $media_file = $this->get_media_file();
        $last_download = get_option('treevine_last_download', '');
        $next_download = wp_next_scheduled('treevine_auto_download');
        $auto_enabled = get_option('treevine_auto_download_enabled', '1');
        
        ob_start();
        ?>
        <table class="form-table">
            <tr>
                <th>Current Media File:</th>
                <td>
                    <?php if ($media_file): ?>
                        <a href="<?php echo esc_url($media_file['url']); ?>" target="_blank">
                            <?php echo esc_html(basename($media_file['file'])); ?>
                        </a>
                        (<?php echo size_format(filesize($media_file['file'])); ?>)
                    <?php else: ?>
                        <em>No file downloaded yet</em>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th>Last Download:</th>
                <td><?php echo $last_download ? esc_html($last_download) : '<em>Never</em>'; ?></td>
            </tr>
            <tr>
                <th>Auto-Download Status:</th>
                <td>
                    <?php 
                    if ($auto_enabled == '1' && $next_download): 
                    ?>
                        <span style="color: green;">✓ Active</span> - Updates every <?php echo get_option('treevine_update_frequency', 1); ?> hour(s)
                    <?php elseif ($auto_enabled == '1' && !$next_download): ?>
                        <span style="color: orange;">⚠ Enabled but not scheduled</span> - Save settings to activate
                    <?php else: ?>
                        <span style="color: gray;">○ Disabled</span>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th>Next Scheduled Download:</th>
                <td>
                    <?php if ($next_download): ?>
                        <strong><?php echo esc_html(date('Y-m-d H:i:s', $next_download)); ?></strong>
                        <span style="color: #666;">(in <?php echo human_time_diff($next_download); ?>)</span>
                    <?php else: ?>
                        <em>Not scheduled - <?php echo $auto_enabled == '1' ? 'Save settings to schedule' : 'Enable auto-download to schedule'; ?></em>
                    <?php endif; ?>
                </td>
            </tr>
        </table>
        <?php
        $html = ob_get_clean();
        
        wp_send_json_success(array('html' => $html));
    }
    
    /**
     * AJAX handler to check if file has been updated
     * Returns last modified timestamp for comparison
     */
    public function ajax_check_file_update() {
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'treevine_check_update')) {
            wp_send_json_error(array('message' => 'Invalid nonce'));
        }
        
        $media_file = $this->get_media_file();
        
        if (!$media_file) {
            wp_send_json_error(array('message' => 'No file available'));
        }
        
        // Get file modification time
        $file_path = $media_file['file'];
        $last_modified = file_exists($file_path) ? filemtime($file_path) : 0;
        
        wp_send_json_success(array(
            'last_modified' => $last_modified,
            'file_name' => basename($file_path)
        ));
    }
    
    /**
     * AJAX handler for manual download
     */
    public function ajax_download_now() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Unauthorized'));
        }
        
        $result = $this->download_file_from_google_drive();
        
        if ($result['success']) {
            wp_send_json_success(array('message' => $result['message']));
        } else {
            wp_send_json_error(array('message' => $result['message']));
        }
    }
    
    /**
     * Auto download file (called by cron)
     */
    public function auto_download_file() {
        if (get_option('treevine_auto_download_enabled', '1') == '1') {
            $this->download_file_from_google_drive();
        }
    }
    
    /**
     * Download file from Google Drive and save to Media Library
     */
    private function download_file_from_google_drive() {
        $google_url = get_option('treevine_google_drive_url', '');
        
        if (empty($google_url)) {
            return array('success' => false, 'message' => 'Google Drive URL not configured');
        }
        
        // Extract file ID
        $file_id = '';
        if (preg_match('/\/file\/d\/([a-zA-Z0-9_-]+)/', $google_url, $matches)) {
            $file_id = $matches[1];
        }
        
        if (empty($file_id)) {
            return array('success' => false, 'message' => 'Could not extract file ID from URL');
        }
        
        // Build download URL
        $download_url = 'https://drive.google.com/uc?export=download&id=' . $file_id;
        
        // Download the file
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        
        $tmp_file = download_url($download_url);
        
        if (is_wp_error($tmp_file)) {
            return array('success' => false, 'message' => 'Download failed: ' . $tmp_file->get_error_message());
        }
        
        // Delete old media file if exists
        $old_media = $this->get_media_file();
        if ($old_media) {
            wp_delete_attachment($old_media['id'], true);
        }
        
        // Prepare file array
        $file_array = array(
            'name' => $this->media_filename,
            'tmp_name' => $tmp_file
        );
        
        // Upload to media library
        $media_id = media_handle_sideload($file_array, 0);
        
        if (is_wp_error($media_id)) {
            @unlink($tmp_file);
            return array('success' => false, 'message' => 'Upload failed: ' . $media_id->get_error_message());
        }
        
        // Save download timestamp
        update_option('treevine_last_download', current_time('mysql'));
        update_option('treevine_media_id', $media_id);
        
        return array('success' => true, 'message' => 'File downloaded successfully!');
    }
    
    /**
     * Get current media file info
     */
    private function get_media_file() {
        $media_id = get_option('treevine_media_id', 0);
        
        if ($media_id) {
            $file_path = get_attached_file($media_id);
            if ($file_path && file_exists($file_path)) {
                return array(
                    'id' => $media_id,
                    'url' => wp_get_attachment_url($media_id),
                    'file' => $file_path
                );
            }
        }
        
        return null;
    }
    
    /**
     * Enqueue CSS and JavaScript
     */
    public function enqueue_assets() {
        global $post;
        if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'treevine_news')) {
            wp_enqueue_style('treevine-player-css', TREEVINE_PLUGIN_URL . 'assets/player.css', array(), TREEVINE_VERSION);
            wp_enqueue_script('treevine-player-js', TREEVINE_PLUGIN_URL . 'assets/player.js', array('jquery'), TREEVINE_VERSION, true);
            
            // Pass AJAX URL and nonce to JavaScript
            wp_localize_script('treevine-player-js', 'treevinePlayerData', array(
                'ajaxurl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('treevine_check_update')
            ));
        }
    }
    
    /**
     * Render player shortcode
     */
    public function render_player_shortcode($atts) {
        $atts = shortcode_atts(array(
            'title' => get_option('treevine_player_title', 'Latest Hourly News')
        ), $atts, 'treevine_news');
        
        // Get media file
        $media_file = $this->get_media_file();
        
        if (!$media_file) {
            return '<p style="color: red;">TreeVine News: No audio file available. Please download from Google Drive in plugin settings.</p>';
        }
        
        // Get settings
        $mini_player = get_option('treevine_mini_player', '0');
        $show_volume = get_option('treevine_show_volume', '');
        $show_timeline = get_option('treevine_show_timeline', '');
        
        // Checkboxes: if value is '1' they're checked, otherwise unchecked
        $volume_hidden = ($show_volume !== '1');
        $timeline_hidden = ($show_timeline !== '1');
        
        // Get MP3 metadata and timestamp
        $metadata = $this->get_mp3_metadata($media_file['id']);
        $timestamp = $this->get_news_timestamp($media_file['id']);
        
        $player_id = 'treevine-player-' . uniqid();
        $player_class = 'treevine-news-player';
        if ($mini_player == '1') {
            $player_class .= ' mini';
            // Add ultra-compact class if controls are hidden
            if ($volume_hidden && $timeline_hidden) {
                $player_class .= ' no-controls';
            }
        }
        
        ob_start();
        
        // Check if we're in ultra-compact mode
        $ultra_compact = ($mini_player == '1' && $volume_hidden && $timeline_hidden);
        
        // Get date format for mini player
        $date_format = get_option('treevine_date_format', 'F j, Y');
        $current_date = date($date_format);
        ?>
        <div class="<?php echo esc_attr($player_class); ?>" id="<?php echo esc_attr($player_id); ?>">
            <?php if ($ultra_compact): ?>
                <div class="treevine-mini-header">
                    <h3 class="treevine-mini-title"><?php echo esc_html($current_date); ?></h3>
                </div>
                <?php if ($timestamp): ?>
                <div class="treevine-compact-subtitle">
                    TreeVine • <?php echo esc_html($timestamp['album_text']); ?> <?php echo esc_html($timestamp['time']); ?> <?php echo esc_html($timestamp['timezone']); ?>
                </div>
                <?php endif; ?>
            <?php else: ?>
            <div class="treevine-player-header">
                <h3 class="treevine-player-title"><?php echo esc_html($atts['title']); ?></h3>
                <?php if ($timestamp): ?>
                    <div class="treevine-player-metadata">
                        <div class="metadata-subtitle">
                            TreeVine • <?php echo esc_html($timestamp['album_text']); ?> <?php echo esc_html($timestamp['time']); ?> <?php echo esc_html($timestamp['timezone']); ?>
                        </div>
                    </div>
                <?php elseif (!empty($metadata)): ?>
                    <div class="treevine-player-metadata">
                        <?php if (!empty($metadata['title'])): ?>
                            <div class="metadata-title"><?php echo esc_html($metadata['title']); ?></div>
                        <?php endif; ?>
                        <?php if (!empty($metadata['artist']) || !empty($metadata['album'])): ?>
                            <div class="metadata-info">
                                <?php 
                                $info_parts = array();
                                if (!empty($metadata['artist'])) $info_parts[] = esc_html($metadata['artist']);
                                if (!empty($metadata['album'])) $info_parts[] = esc_html($metadata['album']);
                                echo implode(' • ', $info_parts);
                                ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            
            <div class="treevine-player-controls">
                <button class="treevine-play-btn">
                    <span class="play-icon">▶</span>
                    <span class="pause-icon" style="display: none;">⏸</span>
                    <span class="btn-text">Play Latest News</span>
                </button>
            </div>
            
            <?php if (!$timeline_hidden): ?>
            <div class="treevine-player-progress">
                <div class="treevine-time-current">0:00</div>
                <div class="treevine-progress-bar">
                    <div class="treevine-progress-fill"></div>
                </div>
                <div class="treevine-time-duration">--:--</div>
            </div>
            <?php endif; ?>
            
            <?php if (!$volume_hidden): ?>
            <div class="treevine-player-volume">
                <span class="volume-icon">🔊</span>
                <input type="range" class="treevine-volume-slider" min="0" max="100" value="80">
            </div>
            <?php endif; ?>
            
            <audio class="treevine-audio-element" preload="metadata">
                <source src="<?php echo esc_url($media_file['url']); ?>" type="audio/mpeg">
                Your browser does not support the audio element.
            </audio>
            
            <?php if (!$ultra_compact): ?>
            <div class="treevine-player-status"></div>
            <?php endif; ?>
            
            <?php if (!$ultra_compact): ?>
            <div class="treevine-player-footer">
                Hourly news provided by <a href="https://treevine.org" target="_blank" rel="noopener">TreeVine.org</a>
            </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Extract and format timestamp from filename or metadata
     */
    private function get_news_timestamp($attachment_id) {
        $metadata = wp_get_attachment_metadata($attachment_id);
        
        // Get album from metadata (e.g., "News_Briefing_for_12:00" or "News_Briefing_for_7:00")
        $album = isset($metadata['album']) ? $metadata['album'] : '';
        
        if (empty($album)) {
            return null;
        }
        
        // Find the last underscore and extract everything after it
        $last_underscore_pos = strrpos($album, '_');
        
        if ($last_underscore_pos === false) {
            // No underscore found, try to extract time from end
            $time_string = substr($album, -5);
        } else {
            // Get everything after the last underscore
            $time_string = substr($album, $last_underscore_pos + 1);
        }
        
        // Validate it's a time format (H:MM or HH:MM - allows single or double digit hours)
        if (!preg_match('/^(\d{1,2}):(\d{2})$/', $time_string, $matches)) {
            return null;
        }
        
        $hour = $matches[1];
        $minute = $matches[2];
        
        try {
            // Get current date in LA timezone (where the file originates)
            $now = new DateTime('now', new DateTimeZone('America/Los_Angeles'));
            $file_date = $now->format('Y-m-d');
            
            // Create datetime with the time from album metadata (in LA timezone)
            $datetime = new DateTime($file_date . ' ' . $hour . ':' . $minute, new DateTimeZone('America/Los_Angeles'));
            
            // Get display timezone from settings (defaults to WordPress timezone)
            $display_timezone_string = get_option('treevine_timezone', wp_timezone_string());
            $display_timezone = new DateTimeZone($display_timezone_string);
            
            // Convert to display timezone
            $datetime->setTimezone($display_timezone);
            
            // Format the album text for display (e.g., "News Briefing for")
            $album_text = str_replace('_', ' ', $album);
            $album_text = preg_replace('/\d{1,2}:\d{2}$/', '', $album_text); // Remove the time (1 or 2 digit hours)
            $album_text = trim($album_text);
            
            return array(
                'album_text' => $album_text,
                'time' => $datetime->format('H:i'),
                'timezone' => $display_timezone_string
            );
        } catch (Exception $e) {
            // If timezone conversion fails, return null
            return null;
        }
    }
    
    /**
     * Get MP3 metadata from WordPress attachment
     */
    private function get_mp3_metadata($attachment_id) {
        $metadata = wp_get_attachment_metadata($attachment_id);
        
        $result = array();
        
        // Get title from attachment post title or ID3 tag
        $post = get_post($attachment_id);
        if ($post && $post->post_title && $post->post_title != 'treevine-latest-news') {
            $result['title'] = $post->post_title;
        }
        
        // Try to get ID3 tags if available
        if (isset($metadata['artist']) && !empty($metadata['artist'])) {
            $result['artist'] = $metadata['artist'];
        }
        
        if (isset($metadata['album']) && !empty($metadata['album'])) {
            $result['album'] = $metadata['album'];
        }
        
        if (isset($metadata['length_formatted']) && !empty($metadata['length_formatted'])) {
            $result['duration'] = $metadata['length_formatted'];
        } elseif (isset($metadata['length']) && !empty($metadata['length'])) {
            $minutes = floor($metadata['length'] / 60);
            $seconds = $metadata['length'] % 60;
            $result['duration'] = sprintf('%d:%02d', $minutes, $seconds);
        }
        
        return $result;
    }
}

// Initialize the plugin
function treevine_news_player_init() {
    return TreeVine_News_Player::get_instance();
}
add_action('plugins_loaded', 'treevine_news_player_init');
