/**
 * TreeVine News Player - JavaScript
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        // Initialize all players on the page
        $('.treevine-news-player').each(function() {
            initPlayer($(this));
        });
    });
    
    function initPlayer($container) {
        const $audio = $container.find('.treevine-audio-element')[0];
        const $playBtn = $container.find('.treevine-play-btn');
        const $playIcon = $container.find('.play-icon');
        const $pauseIcon = $container.find('.pause-icon');
        const $btnText = $container.find('.btn-text');
        const $progressBar = $container.find('.treevine-progress-bar');
        const $progressFill = $container.find('.treevine-progress-fill');
        const $timeCurrent = $container.find('.treevine-time-current');
        const $timeDuration = $container.find('.treevine-time-duration');
        const $volumeSlider = $container.find('.treevine-volume-slider');
        const $status = $container.find('.treevine-player-status');
        
        // Check if using preview URL and needs conversion
        const audioSrc = $audio.querySelector('source').src;
        if (audioSrc.includes('/preview')) {
            // Extract file ID and convert to direct stream URL
            const fileIdMatch = audioSrc.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
            if (fileIdMatch) {
                const fileId = fileIdMatch[1];
                // Use the googleusercontent.com direct link which works for streaming
                const directUrl = `https://drive.usercontent.google.com/download?id=${fileId}&export=download&authuser=0`;
                $audio.querySelector('source').src = directUrl;
                $audio.load();
            }
        }
        
        // Set initial volume (only if volume slider exists)
        if ($volumeSlider.length > 0) {
            $audio.volume = $volumeSlider.val() / 100;
        } else {
            $audio.volume = 0.8; // Default 80% if no slider
        }
        
        // Play/Pause button
        $playBtn.on('click', function() {
            if ($audio.paused) {
                playAudio();
            } else {
                pauseAudio();
            }
        });
        
        function playAudio() {
            const playPromise = $audio.play();
            
            if (playPromise !== undefined) {
                playPromise
                    .then(function() {
                        // Playback started successfully
                        $playBtn.addClass('playing');
                        $playIcon.hide();
                        $pauseIcon.show();
                        $btnText.text('Pause');
                        $status.removeClass('error loading').text('');
                    })
                    .catch(function(error) {
                        // Auto-play was prevented
                        console.error('Playback failed:', error);
                        $status.addClass('error').text('Unable to play. Click play again.');
                    });
            }
        }
        
        function pauseAudio() {
            $audio.pause();
            $playBtn.removeClass('playing');
            $playIcon.show();
            $pauseIcon.hide();
            $btnText.text('Play Latest News');
        }
        
        // Update progress bar as audio plays (only if elements exist)
        $audio.addEventListener('timeupdate', function() {
            if ($audio.duration) {
                if ($progressFill.length > 0) {
                    const percent = ($audio.currentTime / $audio.duration) * 100;
                    $progressFill.css('width', percent + '%');
                }
                if ($timeCurrent.length > 0) {
                    $timeCurrent.text(formatTime($audio.currentTime));
                }
            }
        });
        
        // Update duration when metadata loads (only if element exists)
        $audio.addEventListener('loadedmetadata', function() {
            if ($timeDuration.length > 0) {
                $timeDuration.text(formatTime($audio.duration));
            }
            if ($status.length > 0) {
                $status.removeClass('loading').text('');
            }
        });
        
        // Show loading status (only if element exists)
        $audio.addEventListener('loadstart', function() {
            if ($status.length > 0) {
                $status.addClass('loading').text('Loading audio...');
            }
        });
        
        // Handle errors
        $audio.addEventListener('error', function(e) {
            let errorMessage = 'Error loading audio';
            
            if ($audio.error) {
                switch ($audio.error.code) {
                    case $audio.error.MEDIA_ERR_ABORTED:
                        errorMessage = 'Playback aborted';
                        break;
                    case $audio.error.MEDIA_ERR_NETWORK:
                        errorMessage = 'Network error - check connection';
                        break;
                    case $audio.error.MEDIA_ERR_DECODE:
                        errorMessage = 'Audio file corrupted';
                        break;
                    case $audio.error.MEDIA_ERR_SRC_NOT_SUPPORTED:
                        errorMessage = 'Audio format not supported';
                        break;
                }
            }
            
            $status.addClass('error').text(errorMessage);
            console.error('Audio error:', $audio.error);
        });
        
        // When audio ends
        $audio.addEventListener('ended', function() {
            pauseAudio();
            $audio.currentTime = 0;
            if ($progressFill.length > 0) {
                $progressFill.css('width', '0%');
            }
            if ($timeCurrent.length > 0) {
                $timeCurrent.text('0:00');
            }
        });
        
        // Click on progress bar to seek (only if progress bar exists)
        if ($progressBar.length > 0) {
            $progressBar.on('click', function(e) {
                if ($audio.duration) {
                    const rect = this.getBoundingClientRect();
                    const percent = (e.clientX - rect.left) / rect.width;
                    $audio.currentTime = percent * $audio.duration;
                }
            });
        }
        
        // Volume control (only if volume slider exists)
        if ($volumeSlider.length > 0) {
            $volumeSlider.on('input', function() {
                $audio.volume = $(this).val() / 100;
            });
        }
        
        // Keyboard support
        $(document).on('keydown', function(e) {
            // Space bar to play/pause (only if player is in viewport)
            if (e.keyCode === 32 && isElementInViewport($container[0])) {
                e.preventDefault();
                $playBtn.click();
            }
        });
    }
    
    /**
     * Format seconds to MM:SS
     */
    function formatTime(seconds) {
        if (isNaN(seconds) || seconds === Infinity) {
            return '--:--';
        }
        
        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return mins + ':' + (secs < 10 ? '0' : '') + secs;
    }
    
    /**
     * Check if element is in viewport
     */
    function isElementInViewport(el) {
        const rect = el.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    }
    
    /**
     * Auto-refresh player when new file is available
     * Checks every 2 minutes for file updates via AJAX
     */
    var lastModified = null;
    var checkInterval = 120000; // 2 minutes
    
    function checkForNewFile() {
        // Only run if we have a player on the page
        if ($('.treevine-news-player').length === 0) return;
        
        // Make AJAX call to check file status
        $.ajax({
            url: treevinePlayerData.ajaxurl,
            method: 'POST',
            data: {
                action: 'treevine_check_file_update',
                nonce: treevinePlayerData.nonce
            },
            success: function(response) {
                if (response.success && response.data.last_modified) {
                    var newModified = response.data.last_modified;
                    
                    // First time - just store it
                    if (lastModified === null) {
                        lastModified = newModified;
                        console.log('TreeVine: Monitoring for file updates...');
                        return;
                    }
                    
                    // File has been updated!
                    if (newModified !== lastModified) {
                        console.log('TreeVine: New file detected! Reloading player...');
                        
                        // Pause any playing audio
                        $('.treevine-audio-element').each(function() {
                            this.pause();
                        });
                        
                        // Show notification
                        $('<div class="treevine-update-notice" style="position:fixed;top:20px;right:20px;background:#46b450;color:white;padding:15px 20px;border-radius:5px;box-shadow:0 2px 5px rgba(0,0,0,0.2);z-index:9999;">New audio available! Refreshing...</div>')
                            .appendTo('body')
                            .delay(2000)
                            .fadeOut(500, function() {
                                location.reload();
                            });
                    }
                }
            }
        });
    }
    
    // Only start checking if not in admin
    if (typeof treevinePlayerData !== 'undefined') {
        // Initial check after 30 seconds
        setTimeout(checkForNewFile, 30000);
        
        // Then check every 2 minutes
        setInterval(checkForNewFile, checkInterval);
    }
    
})(jQuery);
