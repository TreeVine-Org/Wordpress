/**
 * TreeVine News Player - JavaScript
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        // Initialize all players on the page
        $('.treevine-news-player').each(function() {
            initPlayer($(this));
        });
    });

    function initPlayer($container) {
        const $audio = $container.find('.treevine-audio-element')[0];
        const $playBtn = $container.find('.treevine-play-btn');
        const $playIcon = $container.find('.play-icon');
        const $pauseIcon = $container.find('.pause-icon');
        const $btnText = $container.find('.btn-text');
        const $progressBar = $container.find('.treevine-progress-bar');
        const $progressFill = $container.find('.treevine-progress-fill');
        const $timeCurrent = $container.find('.treevine-time-current');
        const $timeDuration = $container.find('.treevine-time-duration');
        const $volumeSlider = $container.find('.treevine-volume-slider');
        const $status = $container.find('.treevine-player-status');

        // Track whether we're playing news or a live stream
        var isStreamMode = false;
        var currentStreamInfo = null;

        // Check if using preview URL and needs conversion
        const audioSrc = $audio.querySelector('source').src;
        if (audioSrc.includes('/preview')) {
            // Extract file ID and convert to direct stream URL
            const fileIdMatch = audioSrc.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
            if (fileIdMatch) {
                const fileId = fileIdMatch[1];
                // Use the googleusercontent.com direct link which works for streaming
                const directUrl = `https://drive.usercontent.google.com/download?id=${fileId}&export=download&authuser=0`;
                $audio.querySelector('source').src = directUrl;
                $audio.load();
            }
        }

        // Store original news source for returning to it
        var originalSrc = $audio.querySelector('source').src;

        // Set initial volume (only if volume slider exists)
        if ($volumeSlider.length > 0) {
            $audio.volume = $volumeSlider.val() / 100;
        } else {
            $audio.volume = 0.8; // Default 80% if no slider
        }

        // Play/Pause button
        $playBtn.on('click', function() {
            if ($audio.paused) {
                playAudio();
            } else {
                pauseAudio();
            }
        });

        function playAudio() {
            const playPromise = $audio.play();

            if (playPromise !== undefined) {
                playPromise
                    .then(function() {
                        // Playback started successfully
                        $playBtn.addClass('playing');
                        $playIcon.hide();
                        $pauseIcon.show();
                        if (isStreamMode && currentStreamInfo) {
                            $btnText.text('Stop ' + currentStreamInfo.stationName);
                        } else {
                            $btnText.text('Pause');
                        }
                        $status.removeClass('error loading').text('');
                    })
                    .catch(function(error) {
                        // Auto-play was prevented
                        console.error('Playback failed:', error);
                        $status.addClass('error').text('Unable to play. Click play again.');
                    });
            }
        }

        function pauseAudio() {
            $audio.pause();
            // If in stream mode, fully stop by clearing src
            if (isStreamMode) {
                $audio.src = '';
                stopStream();
            }
            $playBtn.removeClass('playing');
            $playIcon.show();
            $pauseIcon.hide();
            $btnText.text('Play Latest News');
        }

        /**
         * Switch player to live stream mode
         */
        function switchToStream(streamUrl, stationInfo) {
            isStreamMode = true;
            currentStreamInfo = stationInfo;

            console.log('TreeVine: Switching to live stream - ' + stationInfo.stationName);

            // Update the audio source to the Icecast stream
            $audio.querySelector('source').src = streamUrl;
            $audio.load();

            // Update UI to reflect stream mode
            $container.addClass('treevine-stream-mode');
            $btnText.text('Loading ' + stationInfo.stationName + '...');

            // Update status/subtitle with stream info
            var streamLabel = stationInfo.stationName;
            if (stationInfo.songName) {
                streamLabel += ' — ' + stationInfo.songName;
            }
            if (stationInfo.artist) {
                streamLabel += ' by ' + stationInfo.artist;
            }

            var $subtitle = $container.find('.treevine-compact-subtitle, .metadata-subtitle');
            if ($subtitle.length > 0) {
                $subtitle.data('original-text', $subtitle.text());
                $subtitle.text('Live: ' + streamLabel);
            }

            // Hide progress bar (streams don't have duration)
            $container.find('.treevine-player-progress').hide();

            // Show status
            if ($status.length > 0) {
                $status.removeClass('error').addClass('loading').text('Connecting to ' + stationInfo.stationName + '...');
            }

            // Play the stream
            playAudio();
        }

        /**
         * Stop stream and revert to news mode
         */
        function stopStream() {
            isStreamMode = false;
            currentStreamInfo = null;

            // Restore original audio source
            $audio.querySelector('source').src = originalSrc;
            $audio.load();

            // Revert UI
            $container.removeClass('treevine-stream-mode');

            // Restore subtitle
            var $subtitle = $container.find('.treevine-compact-subtitle, .metadata-subtitle');
            if ($subtitle.length > 0 && $subtitle.data('original-text')) {
                $subtitle.text($subtitle.data('original-text'));
            }

            // Restore progress bar visibility
            $container.find('.treevine-player-progress').show();

            if ($status.length > 0) {
                $status.removeClass('loading error').text('');
            }
        }

        /**
         * Try to connect to a station via the WP AJAX proxy
         * Returns a promise that resolves with station info or rejects
         */
        function checkStation(stationName) {
            return $.ajax({
                url: treevinePlayerData.ajaxurl,
                method: 'POST',
                data: {
                    action: 'treevine_check_station',
                    nonce: treevinePlayerData.nonce,
                    station: stationName
                }
            }).then(function(response) {
                if (response.success) {
                    return response.data;
                }
                return $.Deferred().reject(response.data.message).promise();
            });
        }

        /**
         * Attempt stream continuation: try primary, then secondary
         */
        function attemptStreamContinuation() {
            var primary = treevinePlayerData.primaryStation;
            var secondary = treevinePlayerData.secondaryStation;

            if ($status.length > 0) {
                $status.removeClass('error').addClass('loading').text('Connecting to live station...');
            }

            // Try primary station
            if (primary) {
                console.log('TreeVine: Trying primary station: ' + primary);
                checkStation(primary)
                    .then(function(data) {
                        switchToStream(data.streamUrl, data);
                    })
                    .fail(function() {
                        console.log('TreeVine: Primary station unavailable, trying secondary...');
                        // Try secondary
                        if (secondary) {
                            checkStation(secondary)
                                .then(function(data) {
                                    switchToStream(data.streamUrl, data);
                                })
                                .fail(function() {
                                    console.log('TreeVine: Both stations unavailable.');
                                    if ($status.length > 0) {
                                        $status.removeClass('loading').text('No live stations available');
                                    }
                                    resetPlayerAfterEnd();
                                });
                        } else {
                            if ($status.length > 0) {
                                $status.removeClass('loading').text('Station unavailable');
                            }
                            resetPlayerAfterEnd();
                        }
                    });
            } else if (secondary) {
                // No primary, try secondary directly
                console.log('TreeVine: Trying secondary station: ' + secondary);
                checkStation(secondary)
                    .then(function(data) {
                        switchToStream(data.streamUrl, data);
                    })
                    .fail(function() {
                        console.log('TreeVine: Secondary station unavailable.');
                        if ($status.length > 0) {
                            $status.removeClass('loading').text('Station unavailable');
                        }
                        resetPlayerAfterEnd();
                    });
            }
        }

        /**
         * Reset player controls after news ends (no stream)
         */
        function resetPlayerAfterEnd() {
            $playBtn.removeClass('playing');
            $playIcon.show();
            $pauseIcon.hide();
            $btnText.text('Play Latest News');
            $audio.currentTime = 0;
            if ($progressFill.length > 0) {
                $progressFill.css('width', '0%');
            }
            if ($timeCurrent.length > 0) {
                $timeCurrent.text('0:00');
            }
        }

        // Update progress bar as audio plays (only if elements exist)
        $audio.addEventListener('timeupdate', function() {
            if ($audio.duration && !isStreamMode) {
                if ($progressFill.length > 0) {
                    const percent = ($audio.currentTime / $audio.duration) * 100;
                    $progressFill.css('width', percent + '%');
                }
                if ($timeCurrent.length > 0) {
                    $timeCurrent.text(formatTime($audio.currentTime));
                }
            }
        });

        // Update duration when metadata loads (only if element exists)
        $audio.addEventListener('loadedmetadata', function() {
            if (!isStreamMode) {
                if ($timeDuration.length > 0) {
                    $timeDuration.text(formatTime($audio.duration));
                }
            }
            if ($status.length > 0) {
                $status.removeClass('loading').text('');
            }
        });

        // Show loading status (only if element exists)
        $audio.addEventListener('loadstart', function() {
            if ($status.length > 0 && !isStreamMode) {
                $status.addClass('loading').text('Loading audio...');
            }
        });

        // Handle errors
        $audio.addEventListener('error', function(e) {
            // Ignore errors when src is empty (from stopping stream)
            if (!$audio.src || $audio.src === window.location.href) return;

            let errorMessage = 'Error loading audio';

            if ($audio.error) {
                switch ($audio.error.code) {
                    case $audio.error.MEDIA_ERR_ABORTED:
                        errorMessage = 'Playback aborted';
                        break;
                    case $audio.error.MEDIA_ERR_NETWORK:
                        errorMessage = 'Network error - check connection';
                        break;
                    case $audio.error.MEDIA_ERR_DECODE:
                        errorMessage = 'Audio file corrupted';
                        break;
                    case $audio.error.MEDIA_ERR_SRC_NOT_SUPPORTED:
                        errorMessage = 'Audio format not supported';
                        break;
                }
            }

            // If stream fails, revert to news mode
            if (isStreamMode) {
                console.log('TreeVine: Stream error, reverting to news mode.');
                stopStream();
                errorMessage = 'Live stream disconnected';
            }

            $status.addClass('error').text(errorMessage);
            console.error('Audio error:', $audio.error);
        });

        // When audio ends — this is where stream continuation happens
        $audio.addEventListener('ended', function() {
            // Only trigger continuation from news playback, not from streams
            if (!isStreamMode && treevinePlayerData.continuePlaying === '1') {
                var primary = treevinePlayerData.primaryStation;
                var secondary = treevinePlayerData.secondaryStation;

                if (primary || secondary) {
                    console.log('TreeVine: News ended. Attempting stream continuation...');
                    attemptStreamContinuation();
                    return;
                }
            }

            // Default behavior: reset player
            resetPlayerAfterEnd();
        });

        // Click on progress bar to seek (only if progress bar exists)
        if ($progressBar.length > 0) {
            $progressBar.on('click', function(e) {
                if ($audio.duration && !isStreamMode) {
                    const rect = this.getBoundingClientRect();
                    const percent = (e.clientX - rect.left) / rect.width;
                    $audio.currentTime = percent * $audio.duration;
                }
            });
        }

        // Volume control (only if volume slider exists)
        if ($volumeSlider.length > 0) {
            $volumeSlider.on('input', function() {
                $audio.volume = $(this).val() / 100;
            });
        }

        // Keyboard support
        $(document).on('keydown', function(e) {
            // Space bar to play/pause (only if player is in viewport)
            if (e.keyCode === 32 && isElementInViewport($container[0])) {
                e.preventDefault();
                $playBtn.click();
            }
        });
    }

    /**
     * Format seconds to MM:SS
     */
    function formatTime(seconds) {
        if (isNaN(seconds) || seconds === Infinity) {
            return '--:--';
        }

        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return mins + ':' + (secs < 10 ? '0' : '') + secs;
    }

    /**
     * Check if element is in viewport
     */
    function isElementInViewport(el) {
        const rect = el.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    }

    /**
     * Auto-refresh player when new file is available
     * Checks every 2 minutes for file updates via AJAX
     */
    var lastModified = null;
    var checkInterval = 120000; // 2 minutes

    function checkForNewFile() {
        // Only run if we have a player on the page
        if ($('.treevine-news-player').length === 0) return;

        // Don't reload if currently streaming live
        if ($('.treevine-stream-mode').length > 0) return;

        // Make AJAX call to check file status
        $.ajax({
            url: treevinePlayerData.ajaxurl,
            method: 'POST',
            data: {
                action: 'treevine_check_file_update',
                nonce: treevinePlayerData.nonce
            },
            success: function(response) {
                if (response.success && response.data.last_modified) {
                    var newModified = response.data.last_modified;

                    // First time - just store it
                    if (lastModified === null) {
                        lastModified = newModified;
                        console.log('TreeVine: Monitoring for file updates...');
                        return;
                    }

                    // File has been updated!
                    if (newModified !== lastModified) {
                        console.log('TreeVine: New file detected! Reloading player...');

                        // Pause any playing audio
                        $('.treevine-audio-element').each(function() {
                            this.pause();
                        });

                        // Show notification
                        $('<div class="treevine-update-notice" style="position:fixed;top:20px;right:20px;background:#46b450;color:white;padding:15px 20px;border-radius:5px;box-shadow:0 2px 5px rgba(0,0,0,0.2);z-index:9999;">New audio available! Refreshing...</div>')
                            .appendTo('body')
                            .delay(2000)
                            .fadeOut(500, function() {
                                location.reload();
                            });
                    }
                }
            }
        });
    }

    // Only start checking if not in admin
    if (typeof treevinePlayerData !== 'undefined') {
        // Initial check after 30 seconds
        setTimeout(checkForNewFile, 30000);

        // Then check every 2 minutes
        setInterval(checkForNewFile, checkInterval);
    }

})(jQuery);
