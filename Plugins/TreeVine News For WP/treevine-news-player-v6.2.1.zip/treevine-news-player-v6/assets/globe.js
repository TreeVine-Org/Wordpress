/**
 * TreeVine News Globe - D3.js Visualization
 * Renders an interactive globe in a modal overlay
 */

(function($) {
    'use strict';

    var globe = null; // Singleton - only one globe instance

    // Expose the open function globally for the button
    window.treevineOpenGlobe = function() {
        var $modal = $('#treevine-globe-modal');
        $modal.addClass('active');
        document.body.style.overflow = 'hidden';

        // Initialize globe on first open
        if (!globe) {
            globe = new TreeVineGlobe($modal.find('.treevine-globe-content')[0]);
        } else {
            globe.resize();
        }
    };

    window.treevineCloseGlobe = function() {
        var $modal = $('#treevine-globe-modal');
        $modal.removeClass('active');
        document.body.style.overflow = '';
        if (globe) {
            globe.stopRotation();
        }
    };

    // Close on Escape key
    $(document).on('keydown', function(e) {
        if (e.keyCode === 27) {
            treevineCloseGlobe();
        }
    });

    /**
     * TreeVineGlobe constructor
     */
    function TreeVineGlobe(container) {
        var self = this;
        this.container = container;
        this.events = [];
        this.autoRotate = true;
        this.rotationTimer = null;

        // Load events data
        var eventsUrl = treevineGlobeData.eventsUrl;
        d3.json(eventsUrl).then(function(data) {
            self.events = data;
            self.init();
        }).catch(function(err) {
            console.error('TreeVine Globe: Could not load events:', err);
            $(container).html('<p style="color:#ff6b6b;text-align:center;padding:40px;">Could not load globe data.</p>');
        });
    }

    TreeVineGlobe.prototype.init = function() {
        var self = this;
        var $c = $(this.container);
        var width = $c.width();
        var height = $c.height();

        // Update event count in controls
        $('#treevine-globe-event-count').text(this.events.length);

        // Create SVG
        this.svg = d3.select(this.container).select('.treevine-globe-svg')
            .attr('width', width)
            .attr('height', height);

        // Projection
        var scale = Math.min(width, height) * 0.4;
        this.projection = d3.geoOrthographic()
            .scale(scale)
            .translate([width / 2, height / 2])
            .clipAngle(90);

        this.path = d3.geoPath().projection(this.projection);
        this.initialScale = scale;

        // Graticule
        var graticule = d3.geoGraticule();

        // Ocean
        this.svg.append('circle')
            .attr('class', 'tv-ocean')
            .attr('cx', width / 2)
            .attr('cy', height / 2)
            .attr('r', scale);

        // Graticule lines
        this.svg.append('path')
            .datum(graticule)
            .attr('class', 'tv-graticule')
            .attr('d', this.path);

        // Equator
        this.svg.append('path')
            .datum({type: 'LineString', coordinates: d3.range(-180, 181, 1).map(function(lon) { return [lon, 0]; })})
            .attr('class', 'tv-equator')
            .attr('d', this.path);

        // Prime Meridian
        this.svg.append('path')
            .datum({type: 'LineString', coordinates: d3.range(-90, 91, 1).map(function(lat) { return [0, lat]; })})
            .attr('class', 'tv-prime-meridian')
            .attr('d', this.path);

        // Land group
        this.landGroup = this.svg.append('g');

        // Marker group
        this.markerGroup = this.svg.append('g');

        // Load world data
        d3.json('https://cdn.jsdelivr.net/npm/world-atlas@2/land-110m.json').then(function(world) {
            var land = topojson.feature(world, world.objects.land);
            self.landGroup.append('path')
                .datum(land)
                .attr('class', 'tv-land')
                .attr('d', self.path);

            self.drawEvents();
        }).catch(function(err) {
            console.error('Could not load world data:', err);
        });

        // Drag interaction
        var drag = d3.drag().on('drag', function(event) {
            var rotate = self.projection.rotate();
            self.projection.rotate([rotate[0] + event.dx * 0.5, rotate[1] - event.dy * 0.5, rotate[2]]);
            self.updateAll();
        });
        this.svg.call(drag);

        // Zoom interaction
        var zoom = d3.zoom()
            .scaleExtent([0.5, 5])
            .on('zoom', function(event) {
                var newScale = self.initialScale * event.transform.k;
                self.projection.scale(newScale);
                self.svg.select('.tv-ocean')
                    .attr('r', newScale);
                self.updateAll();
            });
        this.svg.call(zoom);

        // Start rotation
        this.startRotation();
    };

    TreeVineGlobe.prototype.getColorForYear = function(year) {
        var minYear = 1762, maxYear = 2045;
        var norm = (year - minYear) / (maxYear - minYear);
        if (norm < 0.15) return '#ff4444';
        if (norm < 0.30) return '#ff8800';
        if (norm < 0.45) return '#ffff00';
        if (norm < 0.60) return '#88ff00';
        if (norm < 0.75) return '#00ff00';
        if (norm < 0.90) return '#00ffff';
        return '#ff00ff';
    };

    TreeVineGlobe.prototype.isVisible = function(lon, lat) {
        var rotate = this.projection.rotate();
        var center = [-rotate[0], -rotate[1]];
        var distance = d3.geoDistance([lon, lat], center);
        return distance < (Math.PI / 180) * 95;
    };

    TreeVineGlobe.prototype.drawEvents = function() {
        var self = this;
        var $tooltip = $('#treevine-globe-tooltip');

        this.events.forEach(function(event) {
            var coords = self.projection([event.lon, event.lat]);
            if (!coords) return;

            var visible = self.isVisible(event.lon, event.lat);
            var color = self.getColorForYear(event.year);
            var radius = Math.max(4, event.density * 0.8);

            // Glow for high-density
            if (event.density >= 7) {
                self.markerGroup.append('circle')
                    .attr('cx', coords[0])
                    .attr('cy', coords[1])
                    .attr('r', radius * 3)
                    .attr('class', 'tv-event-glow')
                    .attr('fill', color)
                    .style('display', visible ? null : 'none')
                    .datum(event);
            }

            // Main marker
            self.markerGroup.append('circle')
                .attr('cx', coords[0])
                .attr('cy', coords[1])
                .attr('r', radius)
                .attr('class', 'tv-event-marker')
                .attr('fill', color)
                .style('display', visible ? null : 'none')
                .datum(event)
                .on('mouseover', function(e, d) {
                    var special = d.special ? '<div style="color:#d2691e;margin-top:5px;">&#11088; ' + d.special.toUpperCase() + '</div>' : '';
                    $tooltip.css({
                        display: 'block',
                        left: (e.pageX + 15) + 'px',
                        top: (e.pageY + 15) + 'px'
                    }).html(
                        '<div class="tv-tooltip-year">' + d.year + '</div>' +
                        '<div class="tv-tooltip-location">' + d.location + '</div>' +
                        '<div style="font-size:11px;color:#888;">(' + d.lat.toFixed(1) + ', ' + d.lon.toFixed(1) + ')</div>' +
                        '<div style="margin-top:8px;">' + d.happening + '</div>' +
                        special
                    );
                })
                .on('mouseout', function() {
                    $tooltip.css('display', 'none');
                });
        });
    };

    TreeVineGlobe.prototype.updateMarkers = function() {
        var self = this;
        var scale = this.projection.scale();
        var center = this.projection.translate();

        this.markerGroup.selectAll('circle').each(function(d) {
            if (!d) return;
            var coords = self.projection([d.lon, d.lat]);
            var visible = self.isVisible(d.lon, d.lat);
            var withinGlobe = false;

            if (coords) {
                var dx = coords[0] - center[0];
                var dy = coords[1] - center[1];
                withinGlobe = Math.sqrt(dx * dx + dy * dy) < (scale * 0.95);
            }

            if (coords && visible && withinGlobe) {
                d3.select(this).attr('cx', coords[0]).attr('cy', coords[1]).style('display', null);
            } else {
                d3.select(this).style('display', 'none');
            }
        });
    };

    TreeVineGlobe.prototype.updateAll = function() {
        this.svg.selectAll('path').attr('d', this.path);
        this.updateMarkers();
    };

    TreeVineGlobe.prototype.startRotation = function() {
        var self = this;
        this.autoRotate = true;
        if (this.rotationTimer) this.rotationTimer.stop();

        this.rotationTimer = d3.timer(function() {
            if (self.autoRotate) {
                var rotate = self.projection.rotate();
                self.projection.rotate([rotate[0] + 0.15, rotate[1], rotate[2]]);
                self.updateAll();
            }
        });
    };

    TreeVineGlobe.prototype.stopRotation = function() {
        this.autoRotate = false;
        if (this.rotationTimer) {
            this.rotationTimer.stop();
            this.rotationTimer = null;
        }
    };

    TreeVineGlobe.prototype.toggleRotation = function() {
        if (this.autoRotate) {
            this.stopRotation();
        } else {
            this.startRotation();
        }
        return this.autoRotate;
    };

    TreeVineGlobe.prototype.focusOn = function(lon, lat) {
        this.projection.rotate([-lon, -lat, 0]);
        this.updateAll();
    };

    TreeVineGlobe.prototype.resetView = function() {
        this.projection.rotate([0, 0, 0]).scale(this.initialScale);
        this.svg.select('.tv-ocean').attr('r', this.initialScale);
        this.updateAll();
    };

    TreeVineGlobe.prototype.resize = function() {
        if (!this.svg) return;
        var $c = $(this.container);
        var width = $c.width();
        var height = $c.height();
        var scale = Math.min(width, height) * 0.4;

        this.svg.attr('width', width).attr('height', height);
        this.initialScale = scale;
        this.projection.scale(scale).translate([width / 2, height / 2]);
        this.svg.select('.tv-ocean')
            .attr('cx', width / 2)
            .attr('cy', height / 2)
            .attr('r', scale);
        this.updateAll();
    };

    // Wire up control buttons (delegated since modal HTML may load late)
    $(document).on('click', '#tv-btn-americas', function() { if (globe) globe.focusOn(80, 20); });
    $(document).on('click', '#tv-btn-europe', function() { if (globe) globe.focusOn(10, 50); });
    $(document).on('click', '#tv-btn-asia', function() { if (globe) globe.focusOn(100, 30); });
    $(document).on('click', '#tv-btn-reset', function() { if (globe) globe.resetView(); });
    $(document).on('click', '#tv-btn-rotate', function() {
        if (globe) {
            var on = globe.toggleRotation();
            $(this).find('.tv-rotate-status').text(on ? 'ON' : 'OFF');
        }
    });

    // Handle resize
    $(window).on('resize', function() {
        if (globe && $('#treevine-globe-modal').hasClass('active')) {
            globe.resize();
        }
    });

})(jQuery);
